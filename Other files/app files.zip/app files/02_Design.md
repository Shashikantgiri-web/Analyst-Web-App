# Design Specification Document

Version: 1.0
Status: Draft
Related Documents:
- 01_PRD.md
- 03_Technology.md
- 04_Features_Buttons.md

---

# 1. Purpose

This document defines the complete visual language, user experience, design system, layouts, interactions, responsiveness, animations, icons, typography, spacing, colors, and reusable components of the Employee Performance Analytics Web Application.

The goal is to ensure that every page follows the same design language regardless of who develops the frontend.

This document acts as the single source of truth for UI and UX implementation.

---

# 2. Design Philosophy

The application is not a marketing website.

It is an Enterprise Analytics Platform used daily by CEOs, Managers, Analysts, Employees, and Testers.

Therefore the design should prioritize:

• Fast information scanning
• Minimal distractions
• High readability
• Professional appearance
• Data-first interface
• Consistency
• Accessibility
• Performance

The interface should feel similar to modern enterprise software such as:

- Microsoft Power BI
- Notion
- Linear
- Jira
- GitHub
- Azure Portal
- Vercel Dashboard

while maintaining its own visual identity.

---

# 3. Overall Style

Theme

Enterprise Dark

Characteristics

• Clean
• Professional
• Modern
• Spacious
• Data-focused
• Rounded Components
• Smooth Animations

No glassmorphism.

No heavy gradients.

No neon effects.

No unnecessary decoration.

Data should always remain the primary focus.

---

# 4. Color Palette

Primary Background

#F5F7FA

Sidebar

#1A2332

Secondary Sidebar

#2A3441

Primary Accent

#FF6B35

Success

#22C55E

Warning

#FACC15

Danger

#EF4444

Info

#3B82F6

Border

#E5E7EB

Card Background

#FFFFFF

Text Primary

#111827

Text Secondary

#6B7280

Disabled

#9CA3AF

---

# 5. Typography

Primary Font

Plus Jakarta Sans

Fallback

Inter

System UI

Font Sizes

Page Title
30px

Section Title
20px

Card Title
18px

Body
14px

Caption
12px

Button
14px

Weight

Regular 400

Medium 500

SemiBold 600

Bold 700

ExtraBold 800

---

# 6. Grid System

Desktop

12 Columns

Laptop

12 Columns

Tablet

8 Columns

Mobile

4 Columns

Maximum Width

1600px

Content Padding

24px

Gap

24px

Card Padding

20px

Border Radius

12px

---

# 7. Layout Structure

Every dashboard must use:

Header

↓

Sidebar

↓

Content Header

↓

Filters

↓

KPI Cards

↓

Charts

↓

Tables

↓

Footer

Never place charts above filters.

Never place tables before KPIs.

---

# 8. Navigation

Sidebar Width

256px

Collapsed Width

72px

Fixed Position

Yes

Scrollable

Yes

Active Item

Orange Border Left

Orange Background Tint

Icons

Lucide Icons

---

# 9. Header

Height

64px

Contains

Logo

Search

Notifications

Profile

Theme Toggle

Breadcrumb

Quick Actions

---

# 10. Cards

Every KPI Card contains

Title

Main Number

Comparison

Trend

Icon

Hover Shadow

Rounded Corners

Padding

20px

---

# 11. Tables

Sticky Header

Pagination

Sorting

Filtering

Search

Row Hover

Bulk Selection

CSV Export

Excel Export

PDF Export

---

# 12. Charts

Preferred Libraries

Recharts

ApexCharts

Charts must use consistent colors.

Never use random chart colors.

Performance

Orange

Satisfaction

Green

Salary

Blue

Warning

Yellow

Negative

Red

---

# 13. Icons

Library

Lucide React

Size

18

20

24

Do not mix icon libraries.

---

# 14. Buttons

Primary

Orange

Secondary

White

Danger

Red

Ghost

Transparent

Icon Buttons

32x32

Radius

8px

---

# 15. Forms

Input Height

44px

Border Radius

8px

Focus Border

Orange

Validation

Inline

Required Fields

Marked *

---

# 16. Loading States

Skeleton Cards

Skeleton Charts

Skeleton Tables

Loading Spinner

Progress Bar

---

# 17. Empty States

Illustration

Message

Action Button

No blank pages.

---

# 18. Error States

404

403

401

500

Offline

Database Error

Unauthorized

---

# 19. Animations

Duration

200ms

Hover

Fade

Scale 1.02

Drawer

Slide

Modal

Fade + Scale

Charts

Animated on first load only.

---

# 20. Responsive Design

Desktop

1600+

Laptop

1280

Tablet

768

Mobile

390

Sidebar

Collapse automatically.

Charts become stacked.

Tables become cards on mobile.

---

# 21. Accessibility

Keyboard Navigation

Focus States

Screen Reader Labels

ARIA Support

Color Contrast WCAG AA

---

# 22. Profile Avatar

Use the following design style.

Reference

A minimal floating glowing sphere.

Soft cyan, violet, blue gradients.

White geometric facial lines.

Calm expression.

Soft off-white background.

Use this style for all default user avatars.

---

# 23. Dashboard Consistency Rules

Every page must contain:

Header

Breadcrumb

Filters

KPIs

Charts

Tables

Pagination

Footer

Every page should look like part of one application.

---

# 24. Design Constraints

Never use more than one primary color.

Never mix fonts.

Never use more than 8px border radius on buttons.

Never use glassmorphism.

Never use inconsistent spacing.

Never use multiple shadow styles.

Never use more than two animation styles.

Consistency is more important than creativity.

---

# 25. AI Design Instructions

When AI generates UI:

Maintain component consistency.

Reuse existing components.

Do not invent new colors.

Do not invent new spacing.

Do not change typography.

Do not redesign layouts without updating this document.

Always follow this Design Specification before generating UI.