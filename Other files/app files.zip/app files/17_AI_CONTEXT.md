# AI Context

Project

Employee Performance Analytics Platform

Purpose

This document provides the minimum required context for AI coding assistants working on this project.

Read this file first before generating any code.

---

# Project Summary

The Employee Performance Analytics Platform is a web application that helps organizations monitor, analyze, and improve employee performance.

The system includes:

- CEO Dashboard
- Manager Dashboard
- Employee Dashboard
- Tester Dashboard
- AI Business Assistant
- ETL Pipeline
- Power BI Integration
- Reporting System
- Notification System

---

# Technology Stack

Frontend

- Next.js (JavaScript)
- React
- Tailwind CSS
- shadcn/ui

Backend

- Next.js Server Actions
- Supabase

Database

- PostgreSQL

Authentication

- Supabase Auth

Validation

- Zod

Charts

- Recharts

Deployment

- Vercel

---

# Important Rules

This project uses JavaScript only.

Do not generate TypeScript.

Do not create .ts or .tsx files.

Use ES Modules.

Use async/await.

Use Server Actions before Route Handlers.

Never bypass Row Level Security.

Never expose service role keys.

Never duplicate business logic.

---

# Project Structure

Follow:

docs/12_Project_Structure.md

Never create folders outside the approved structure.

---

# Database

Follow:

docs/11_Database_Design.md

Never rename tables.

Never rename columns.

Always use foreign keys.

Always use lookup tables.

---

# API

Follow:

docs/13_API_Architecture.md

Use:

UI

↓

Server Actions

↓

Services

↓

Repositories

↓

Supabase

↓

Database

---

# AI

Follow:

docs/14_AI_Architecture.md

AI is a Business Assistant.

Not a chatbot.

Always use:

Prompt Builder

↓

Context Manager

↓

AI Service

↓

Response Formatter

---

# Coding Rules

Follow:

docs/15_Coding_Standards.md

JavaScript only.

Clean architecture.

Reusable components.

Modular services.

---

# Development Order

Read:

01_PRD.md

↓

03_Technology.md

↓

11_Database_Design.md

↓

12_Project_Structure.md

↓

13_API_Architecture.md

↓

14_AI_Architecture.md

↓

15_Coding_Standards.md

↓

Implement requested feature.

---

# AI Behavior

Before generating code:

Understand the requested feature.

Identify affected modules.

Reuse existing components.

Reuse services.

Reuse repositories.

Avoid duplicate code.

Follow project architecture.

Update documentation if architecture changes.

---

# Definition of Done

Every generated feature must:

✓ Follow project architecture.

✓ Follow coding standards.

✓ Follow database design.

✓ Follow API architecture.

✓ Respect permissions.

✓ Validate inputs.

✓ Handle errors.

✓ Be production-ready.

---

This document is the entry point for every AI coding assistant working on the Employee Performance Analytics Platform.