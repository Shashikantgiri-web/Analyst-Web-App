# Project Structure Specification

Version: 1.0

Status: Approved

Document Type

System Architecture

Project

Employee Performance Analytics Platform

---

# 1. Purpose

This document defines the official folder structure, module organization, file naming conventions, application architecture, and development boundaries for the Employee Performance Analytics Platform.

Every developer and AI assistant must follow this structure when creating new files.

This document is the single source of truth for project organization.

---

# 2. Required Reading

Before implementing any feature, read:

1. 01_PRD.md
2. 03_Technology.md
3. 11_Database_Design.md

Reference as needed:

- 13_API_Architecture.md
- 14_AI_Architecture.md
- 15_Coding_Standards.md

---

# 3. Architecture Overview

Application Architecture

Frontend (Next.js)

↓

Server Actions

↓

Business Services

↓

Supabase

↓

PostgreSQL

↓

AI Layer

↓

Dashboard

The architecture follows a layered approach where each layer has a single responsibility.

---

# 4. Root Directory Structure

employee-performance-platform/

app/

components/

features/

actions/

services/

lib/

hooks/

providers/

middleware/

database/

types/

constants/

utils/

styles/

public/

scripts/

tests/

docs/

.env.local

package.json

README.md

---

# 5. App Directory

Uses the Next.js App Router.

app/

layout.tsx

page.tsx

loading.tsx

error.tsx

not-found.tsx

about/

login/

ceo/

manager/

employee/

tester/

api/

---

# 6. Route Structure

/

Login Page

/about

Application Information

/ceo

CEO Dashboard

/manager

Manager Dashboard

/employee

Employee Dashboard

/tester

Tester Dashboard

---

# 7. Components

components/

ui/

buttons/

cards/

forms/

inputs/

tables/

charts/

navigation/

layout/

dialogs/

icons/

feedback/

common/

Rules

UI components must never contain business logic.

Components must be reusable.

---

# 8. Features

features/

authentication/

dashboard/

employees/

departments/

reports/

notifications/

analytics/

ai/

Purpose

Contains feature-specific logic, hooks, and UI.

---

# 9. Server Actions

actions/

login.ts

employees.ts

dashboard.ts

reports.ts

notifications.ts

ai.ts

Rules

Server Actions handle secure server-side operations.

Never place business logic inside page components.

---

# 10. Services

services/

employee.service.ts

department.service.ts

dashboard.service.ts

report.service.ts

notification.service.ts

ai.service.ts

Purpose

Business logic and communication with Supabase.

---

# 11. Database

database/

schema/

migrations/

seed/

functions/

views/

policies/

Purpose

Contains SQL scripts and database resources.

---

# 12. Library

lib/

supabase/

auth/

ai/

logger/

validators/

cache/

Purpose

Shared infrastructure and integrations.

---

# 13. Hooks

hooks/

use-auth.ts

use-dashboard.ts

use-employees.ts

use-theme.ts

Rules

Hooks manage reusable client-side state and behavior.

---

# 14. Providers

providers/

auth-provider.tsx

theme-provider.tsx

query-provider.tsx

Purpose

Global React providers.

---

# 15. Middleware

middleware/

auth.ts

permissions.ts

logging.ts

Purpose

Authentication and request validation.

---

# 16. Types

types/

employee.ts

department.ts

dashboard.ts

database.ts

api.ts

auth.ts

Purpose

Centralized TypeScript types and interfaces.

---

# 17. Constants

constants/

roles.ts

permissions.ts

routes.ts

theme.ts

charts.ts

messages.ts

Purpose

Shared application constants.

---

# 18. Utilities

utils/

date.ts

salary.ts

performance.ts

validation.ts

formatters.ts

helpers.ts

Purpose

Pure utility functions with no business logic.

---

# 19. Styles

styles/

globals.css

variables.css

animations.css

Purpose

Global styling resources.

---

# 20. Public Assets

public/

images/

icons/

logos/

avatars/

fonts/

illustrations/

---

# 21. Tests

tests/

unit/

integration/

e2e/

fixtures/

mocks/

Purpose

Automated testing resources.

---

# 22. Documentation

docs/

All project documentation is stored here.

Documents should never be duplicated outside this folder.

---

# 23. Naming Conventions

Folders

kebab-case

Files

kebab-case

React Components

PascalCase

Variables

camelCase

Constants

UPPER_SNAKE_CASE

Database Tables

snake_case

---

# 24. Import Rules

Import order

1. External Libraries

2. Internal Libraries

3. Components

4. Features

5. Utilities

6. Types

7. Styles

Avoid circular dependencies.

---

# 25. Folder Responsibility Matrix

app
Routing only

components
Reusable UI

features
Business features

actions
Server Actions

services
Business logic

database
SQL

lib
Shared infrastructure

utils
Helper functions

tests
Testing

docs
Documentation

---

# 26. Development Rules

Never place SQL inside React components.

Never fetch Supabase directly inside UI components.

Never duplicate utilities.

Never mix UI with business logic.

Use feature-based organization.

Reuse components whenever possible.

---

# 27. Future Expansion

mobile/

desktop/

packages/

shared/

microservices/

The structure should support future growth without major reorganization.

---

# 28. Acceptance Criteria

✓ All developers follow the same folder structure.

✓ Every file has a defined location.

✓ No duplicate business logic.

✓ Clear separation of responsibilities.

✓ Scalable architecture.

---

# 29. AI Development Instructions

Before creating any new file:

Read:

- 01_PRD.md
- 03_Technology.md
- 11_Database_Design.md
- 12_Project_Structure.md

Never create folders outside this structure.

Never invent new architecture patterns without updating this document.

Always place new files in their designated module.

This document defines the official project organization.