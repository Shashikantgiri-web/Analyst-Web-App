# Database Design Specification

Version: 1.0

Status: Approved

Document Type

System Architecture

Project

Employee Performance Analytics Platform

Related Documents

- 01_PRD.md
- 02_Design.md
- 03_Technology.md
- 04_Functional_Specification.md
- 05_Login_Page.md
- 06_CEO_Dashboard.md
- 07_Manager_Dashboard.md
- 08_Employee_Dashboard.md
- 09_Tester_Dashboard.md
- 10_Quality_Assurance_Deployment.md

---

# 1. Purpose

This document defines the complete database architecture for the Employee Performance Analytics Platform.

It serves as the single source of truth for:

• Database Schema
• Table Design
• Relationships
• Constraints
• Naming Conventions
• SQL Standards
• Authentication
• Row Level Security
• ETL Mapping
• AI Data Access

Every backend service, frontend feature, ETL pipeline, AI module, API, dashboard, and report must follow the rules defined in this document.

---

# 2. Database Philosophy

The database is designed around the following principles.

## 2.1 Normalization

The schema follows Third Normal Form (3NF) where appropriate.

Goals

- Remove duplicate information
- Maintain consistency
- Simplify maintenance
- Improve scalability

---

## 2.2 Single Source of Truth

Each piece of information exists in only one location.

Example

Department names are stored only in the Departments table.

Employee passwords are stored only in Employee Accounts.

Performance metrics are stored only in Employee Metrics.

---

## 2.3 UUID Strategy

Every primary table uses UUID as its primary key.

Reason

- Better scalability
- Prevent predictable IDs
- Easier synchronization
- Better distributed systems support

---

## 2.4 Naming Convention

Tables

snake_case

Examples

employee_metrics

employee_accounts

department_levels

Columns

snake_case

Examples

employee_id

performance_score

created_at

Foreign Keys

table_name_id

Example

department_id

training_level_id

salary_level_id

Boolean Columns

Prefix

is_

Examples

is_active

is_deleted

is_manager

---

# 3. Database Architecture

The database is divided into four logical layers.

Lookup Tables

↓

Core Business Tables

↓

System Tables

↓

Future Expansion Tables

This separation keeps the database organized and maintainable.

---

# 4. High-Level ER Diagram

Departments
      │
      │ 1:N
      ▼
Employees
      │
      ├──────────────┐
      │              │
      ▼              ▼
Employee Metrics   Employee Accounts
      │
      ├──────────────┐
      ▼              ▼
Notifications      Login History
      │
      ▼
Reports
      │
      ▼
AI Logs

---

# 5. Lookup Tables

Lookup tables store reusable reference values.

Benefits

- Prevent duplicate values
- Maintain consistency
- Simplify updates
- Reduce storage

The application uses the following lookup tables.

Departments

Education Levels

Salary Levels

Training Levels

Roles

Employee Statuses

Promotion Statuses

Performance Ratings

Satisfaction Ratings

Remote Work Types

Gender

---

# 6. Lookup Table Definitions

## departments

Purpose

Stores company departments.

Columns

id

UUID

Primary Key

department_code

VARCHAR(20)

Unique

department_name

VARCHAR(100)

Not Null

description

TEXT

manager_employee_id

UUID

Nullable

is_active

BOOLEAN

Default TRUE

created_at

TIMESTAMP

updated_at

TIMESTAMP

---

## education_levels

id

UUID

name

VARCHAR(50)

description

TEXT

---

## salary_levels

id

UUID

name

VARCHAR(50)

minimum_salary

NUMERIC

maximum_salary

NUMERIC

---

## training_levels

id

UUID

name

description

---

## roles

CEO

Manager

Employee

Tester

---

## employee_statuses

Active

Inactive

On Leave

Resigned

Retired

---

## performance_ratings

Excellent

Good

Average

Needs Improvement

Poor

---

## satisfaction_ratings

Very High

High

Medium

Low

Very Low

---

## remote_work_types

Office

Hybrid

Remote

---

# 7. Core Business Tables

The following tables represent the main business entities.

employees

employee_metrics

employee_accounts

---

# 8. Employees Table

Purpose

Stores permanent employee information.

Columns

id

UUID

Primary Key

employee_code

VARCHAR(20)

Unique

first_name

VARCHAR(100)

last_name

VARCHAR(100)

department_id

UUID

education_level_id

UUID

gender

VARCHAR(20)

current_age

INTEGER

hire_date

DATE

years_at_company

INTEGER

employee_status_id

UUID

profile_photo

TEXT

created_at

TIMESTAMP

updated_at

TIMESTAMP

Business Rules

Employee Code must be unique.

Department is mandatory.

Education Level is mandatory.

Age cannot be negative.

Years at company cannot exceed current age.

---

# 9. Employee Metrics

Purpose

Stores analytical values used in dashboards.

Columns

employee_id

UUID

Performance Score

Overall Performance Index

Performance Rating

Min Performance Score

Max Performance Score

Performance Percentage

Monthly Salary

Salary Level

Training Hours

Training Level

Projects Handled

Remaining Projects

Normal Work Hours

Overtime Hours

Total Work Hours

Overall Hours

Workload

Remote Work Frequency

Remote Work Type

Promotion

Promotion Status

Retirement On

Retirement Status

Satisfaction Score

Satisfaction Percentage

Satisfaction Rating

Work Life Balance

Sick Days

Created At

Updated At

Business Rules

One metrics record per employee.

---

# 10. Employee Accounts

Purpose

Authentication

Authorization

Columns

id

employee_id

username

email

password_hash

role_id

is_active

last_login

password_changed_at

created_at

updated_at

Rules

Passwords are never stored as plain text.

Authentication is handled by Supabase Auth.

Email must be unique.

Username must be unique.

---

# 11. System Tables

notifications

login_history

reports

ai_logs

---

# 12. Notifications

Purpose

Store in-app notifications.

Columns

id

employee_id

title

message

type

is_read

created_at

---

# 13. Login History

Purpose

Maintain audit logs.

Columns

id

employee_id

login_time

logout_time

browser

device

ip_address

status

---

# 14. Reports

Purpose

Track generated reports.

Columns

id

employee_id

report_type

file_path

generated_at

download_count

---

# 15. AI Logs

Purpose

Store AI interactions.

Columns

id

employee_id

question

response

model

response_time

created_at

Future

Prompt Tokens

Completion Tokens

Cost

---

# 16. Relationships

Departments

1:N

Employees

Employees

1:1

Employee Metrics

Employees

1:1

Employee Accounts

Employees

1:N

Notifications

Employees

1:N

Reports

Employees

1:N

Login History

Employees

1:N

AI Logs

---

# 17. Constraints

All primary keys use UUID.

All foreign keys enforce referential integrity.

Unique constraints

employee_code

email

username

Department names

Indexes

employee_code

department_id

employee_id

email

role_id

---

# 18. Row Level Security Strategy

CEO

Full Read

Manager

Department Only

Employee

Own Data Only

Tester

Simulation Mode Only

Never bypass RLS.

---

# 19. ETL Mapping

Excel

↓

Python ETL

↓

Validation

↓

Transformation

↓

PostgreSQL

↓

Supabase

↓

Next.js

↓

Dashboard

Each imported column must map to exactly one database field.

---

# 20. Audit Columns

Every business table contains

created_at

updated_at

Future

deleted_at

created_by

updated_by

---

# 21. Future Tables

employee_metrics_history

audit_logs

activity_logs

attachments

comments

saved_reports

dashboard_preferences

api_keys

---

# 22. Development Rules

Never duplicate employee information.

Never store passwords.

Never hardcode departments.

Always use foreign keys.

Always use lookup tables.

Always use UUID.

Always use snake_case.

Always validate before insert.

Always use transactions where multiple tables are updated.

---

# 23. AI Development Instructions

Before generating SQL or backend code:

Read this document completely.

Never rename tables without updating every dependent document.

Never bypass Row Level Security.

Never duplicate data across tables.

Always reference lookup tables.

Always use foreign keys.

Always create indexes for searchable columns.

Keep analytical data separate from authentication data.

This document is the authoritative reference for all database-related development.