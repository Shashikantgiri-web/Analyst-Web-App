# Technology Specification

Version: 1.0

Status: Approved

Related Documents

- 01_PRD.md
- 02_Design.md
- 04_Features_Buttons.md
- 12_Database.md
- 13_Project_Structure.md
- 14_API.md

---

# 1. Purpose

This document defines every technology, framework, package, coding standard, development rule, and software version used throughout the Employee Performance Analytics Web Application.

Every developer and AI assistant must follow this document before writing any code.

No technology should be replaced without updating this document.

---

# 2. Architecture Overview

Application Type

Enterprise Full Stack Web Application

Architecture

Client
↓

Next.js Frontend

↓

Server Actions / API Routes

↓

Supabase PostgreSQL

↓

Power BI Processed Data

↓

Python ETL Pipeline

The application follows a modern Full Stack architecture using Next.js.

---

# 3. Frontend

Framework

Next.js

Version

Latest Stable Version

Language

JavaScript (ES2023)

Reason

The project is intentionally built using JavaScript instead of TypeScript to keep the codebase simple and easier for new developers.

Use App Router only.

Do not use Pages Router.

---

# 4. Styling

Framework

Tailwind CSS

Version

Latest Stable Version

Rules

Never write inline CSS.

Never write large CSS files.

Always use Tailwind utility classes.

Extract reusable UI into components.

Use CSS variables only for theme colors.

---

# 5. Component Library

Preferred

Custom Components

Additional

shadcn/ui (optional)

Icons

Lucide React

Rules

Never mix icon libraries.

Never use Bootstrap components.

Never use Material UI.

---

# 6. Backend

Backend Framework

Next.js Server

Use

Server Actions

Route Handlers

Middleware

Never create a separate Express backend.

---

# 7. Database

Platform

Supabase

Database

PostgreSQL

Hosting

Supabase Cloud

Authentication

Supabase Auth

Storage

Supabase Storage

Realtime

Supabase Realtime (Future)

---

# 8. ORM / Database Access

Preferred

Supabase JavaScript SDK

Optional

Prisma (Future)

Raw SQL

Allowed only when necessary.

---

# 9. Authentication

Platform

Supabase Authentication

Login Methods

Email + Password

Role Based Login

CEO

Manager

Employee

Tester

Future

Google Login

Microsoft Login

Company SSO

MFA

---

# 10. Charts

Primary

Recharts

Secondary

ApexCharts

Rules

Use Recharts whenever possible.

Use ApexCharts only for advanced charts such as:

Gauge

Radial

Heatmap

Box Plot

Radar

---

# 11. Forms

Library

React Hook Form

Validation

Zod

Rules

Every form must be validated.

Never trust frontend validation alone.

Validate again on the server.

---

# 12. Tables

Preferred

TanStack Table

Features

Sorting

Pagination

Filtering

Search

Column Visibility

Export

---

# 13. Date Handling

Library

date-fns

Never manipulate dates manually.

---

# 14. HTTP Requests

Use

Native fetch()

Server Components whenever possible.

Do not use Axios unless absolutely required.

---

# 15. State Management

Local State

React Hooks

Shared State

React Context

Future

Zustand

Redux is not required.

---

# 16. Notifications

Preferred

Sonner

Alternative

React Hot Toast

---

# 17. File Upload

Supabase Storage

Allowed Files

Excel

CSV

PDF

Images

Maximum Upload Size

Configured by environment.

---

# 18. Search

Global Search

Client Search

Server Search

Database Search

Search should support

Employee ID

Department

Employee Name

Email

Manager

---

# 19. Environment Variables

Use

.env.local

Required Variables

NEXT_PUBLIC_SUPABASE_URL

NEXT_PUBLIC_SUPABASE_ANON_KEY

SUPABASE_SERVICE_ROLE_KEY

JWT_SECRET

APP_NAME

APP_URL

Never expose secret keys.

---

# 20. Security

Password Hashing

Handled by Supabase Auth

Authorization

Role Based Access

CSRF Protection

Enabled

XSS Protection

Enabled

SQL Injection Protection

Parameterized Queries

Rate Limiting

Required

HTTPS

Required

---

# 21. AI Integration

Future AI Engine

OpenAI GPT

Possible Providers

OpenAI

Azure OpenAI

Google Gemini

Anthropic Claude

Use AI only through a backend API.

Never expose API keys to the frontend.

---

# 22. Python Pipeline

Purpose

Convert processed Excel files into PostgreSQL tables.

Libraries

Python

Pandas

SQLAlchemy

OpenPyXL

Workflow

Excel

↓

Read Workbook

↓

Clean Columns

↓

Create Tables

↓

Upload to PostgreSQL

---

# 23. Development Tools

Package Manager

npm

Version Control

Git

Hosting

Vercel

IDE

VS Code

Cursor (Optional)

Database GUI

Supabase Dashboard

Git Client

GitHub Desktop

API Testing

Postman

---

# 24. Code Quality

Formatting

Prettier

Linting

ESLint

Rules

No unused imports.

No console.log in production.

Meaningful variable names.

Reusable functions.

Small components.

---

# 25. Performance Rules

Lazy Loading

Required

Dynamic Imports

Required

Image Optimization

Next/Image

Memoization

When necessary

Avoid unnecessary re-renders.

---

# 26. Browser Support

Chrome

Edge

Firefox

Safari

Latest two versions only.

---

# 27. Responsive Support

Desktop

Laptop

Tablet

Mobile

Landscape

Portrait

---

# 28. SEO

Metadata API

Open Graph

Twitter Cards

Sitemap

robots.txt

Canonical URLs

JSON-LD Structured Data

---

# 29. Deployment

Platform

Vercel

Database

Supabase

Domain

Custom Domain

HTTPS

Enabled

Automatic Deploy

GitHub Integration

---

# 30. Versioning

Version Format

Major.Minor.Patch

Example

1.0.0

---

# 31. Future Technologies

Redis

Background Jobs

Supabase Edge Functions

Email Service

Push Notifications

Real-time Analytics

Machine Learning

AI Recommendations

---

# 32. Development Rules

Always use Server Components unless interactivity is required.

Prefer Server Actions over API routes.

Reuse components before creating new ones.

Never duplicate logic.

Keep business logic separate from UI.

Write modular code.

Keep files small and maintainable.

Use async/await instead of promise chains.

Every new dependency must be documented here before being added.

---

# 33. AI Coding Rules

Before generating code, AI must:

Read PRD.md

Read Design.md

Read Technology.md

Read Features_Buttons.md

Never invent libraries.

Never change versions.

Never replace technologies without updating this document.

Always follow the architecture defined in this specification.